# Magic World Importer (prototype 0.1.0)

A minimal Android app project for importing Minecraft Bedrock world and pack archives through Android's Storage Access Framework.

## Current behaviour
- Selects a `.zip`, `.mcworld`, or `.mcpack` archive using Android's file picker.
- Extracts the archive into temporary app storage.
- Detects a world by `level.dat` or a pack by `manifest.json`.
- Lets the user select a destination folder and copies the detected content there.
- Rejects ZIP path traversal and caps extracted data at 1 GiB.
- Adds a numbered folder name rather than overwriting an existing import.

## Important integration limitation
The app currently requires the user to select the actual destination folder. It does not silently assume Magic Loader's private path. Android 11+ restricts access to other apps' private `Android/data` folders, and this APK inspection has not yet confirmed a public world-import API or exact writable world directory in Magic Loader 0.1.2. If Magic Loader's world directory is private and not exposed by its own picker/API, a separate app cannot write there directly without support from Magic Loader.

For a world, select Magic Loader's world-save directory (the parent that contains world folders). For a `.mcpack`, select the corresponding resource-pack or behaviour-pack parent folder. A `.mcpack` is a pack, not a playable world.

## Build
Open this folder in Android Studio with Android SDK 35 installed, then Build > Build APK(s). The generated debug APK is under `app/build/outputs/apk/debug/`.

## Next integration step
Test the selected destination on the device. If Magic Loader provides an import folder or public folder URI, configure that as the default. Otherwise, the app needs an in-app share/import handoff or a Magic Loader-side integration.
