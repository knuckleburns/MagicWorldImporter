package com.knuckleburns.magicworldimporter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var selectedArchive: Uri? = null
    private var selectedName: String = ""

    companion object {
        private const val PICK_ARCHIVE = 10
        private const val PICK_DESTINATION = 11
        private const val MAX_UNPACKED_BYTES = 1024L * 1024L * 1024L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.TOP
            setBackgroundColor(0xFF101010.toInt())
        }
        val title = TextView(this).apply {
            text = "Magic World Importer"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "Import Minecraft worlds and packs into a folder you choose."
            textSize = 14f
            setTextColor(0xFFBDBDBD.toInt())
            setPadding(0, 10, 0, 24)
        }
        val pick = makeButton("SELECT .ZIP / .MCWORLD / .MCPACK") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/zip", "application/octet-stream", "application/x-zip-compressed"
                ))
            }
            startActivityForResult(intent, PICK_ARCHIVE)
        }
        val destination = makeButton("CHOOSE MAGIC LOADER DESTINATION") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            startActivityForResult(intent, PICK_DESTINATION)
        }
        status = TextView(this).apply {
            text = "No file selected.\n\nChoose an archive, then choose the matching Magic Loader folder."
            textSize = 14f
            setTextColor(0xFFE0E0E0.toInt())
            setPadding(0, 24, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(pick, match())
        root.addView(destination, match(12))
        root.addView(status, match(8))
        setContentView(root)
    }

    private fun match(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = top }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            PICK_ARCHIVE -> {
                selectedArchive = uri
                selectedName = queryDisplayName(uri) ?: "minecraft_archive"
                status.text = "Selected: $selectedName\nNow choose the correct destination folder."
            }
            PICK_DESTINATION -> {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(uri, flags)
                val archive = selectedArchive
                if (archive == null) {
                    status.text = "Choose an archive first."
                    return
                }
                importArchive(archive, uri)
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun importArchive(source: Uri, destinationUri: Uri) {
        status.text = "Reading archive…"
        Thread {
            try {
                val temp = File(cacheDir, "import_${System.currentTimeMillis()}").apply { mkdirs() }
                val zipFile = File(temp, "input.zip")
                contentResolver.openInputStream(source)?.use { input ->
                    FileOutputStream(zipFile).use { output -> input.copyTo(output) }
                } ?: error("Could not open selected file")
                val extracted = File(temp, "extracted").apply { mkdirs() }
                unzipSafely(zipFile, extracted)

                val worldMarker = findFile(extracted, "level.dat")
                val packManifest = findFile(extracted, "manifest.json")
                val kind: String
                val contentRoot: File
                if (worldMarker != null) {
                    kind = "WORLD"
                    contentRoot = worldMarker.parentFile ?: extracted
                } else if (packManifest != null) {
                    kind = "PACK"
                    contentRoot = packManifest.parentFile ?: extracted
                } else {
                    error("This archive has no level.dat or manifest.json. It doesn't look like a Minecraft world or pack.")
                }

                val targetRoot = DocumentFile.fromTreeUri(this, destinationUri)
                    ?: error("Destination folder is unavailable")
                val cleanName = contentRoot.name.ifBlank { selectedName.substringBeforeLast('.') }
                    .replace(Regex("[^A-Za-z0-9 _.-]"), "_").take(64).ifBlank { if (kind == "WORLD") "Imported World" else "Imported Pack" }
                val outputDir = targetRoot.createDirectory(uniqueName(targetRoot, cleanName))
                    ?: error("Could not create destination folder. Check write permission.")
                copyTree(contentRoot, outputDir)
                temp.deleteRecursively()
                runOnUiThread {
                    status.text = "$kind IMPORTED\n\nSaved as: ${outputDir.name}\nDestination: ${targetRoot.name ?: "selected folder"}\n\nOpen Magic Loader and check its world/pack list."
                    Toast.makeText(this, "Import complete", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "IMPORT FAILED\n\n${e.message ?: "Unknown error"}" }
            }
        }.start()
    }

    private fun unzipSafely(zipFile: File, outputDir: File) {
        var total = 0L
        ZipInputStream(BufferedInputStream(zipFile.inputStream())).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val out = File(outputDir, entry.name)
                val canonicalRoot = outputDir.canonicalPath + File.separator
                if (out.canonicalPath != outputDir.canonicalPath && !out.canonicalPath.startsWith(canonicalRoot)) {
                    error("Unsafe archive path rejected")
                }
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { stream ->
                        val buffer = ByteArray(32 * 1024)
                        while (true) {
                            val count = zip.read(buffer)
                            if (count < 0) break
                            total += count
                            if (total > MAX_UNPACKED_BYTES) error("Archive is larger than the 1 GB safety limit")
                            stream.write(buffer, 0, count)
                        }
                    }
                }
                zip.closeEntry()
            }
        }
    }

    private fun findFile(root: File, name: String): File? {
        root.walkTopDown().maxDepth(6).firstOrNull { it.isFile && it.name.equals(name, true) }?.let { return it }
        return null
    }

    private fun uniqueName(parent: DocumentFile, base: String): String {
        var candidate = base
        var index = 2
        while (parent.findFile(candidate) != null) candidate = "$base ($index)".also { index++ }
        return candidate
    }

    private fun copyTree(source: File, target: DocumentFile) {
        source.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                val dir = target.createDirectory(child.name ?: "folder") ?: error("Cannot create folder ${child.name}")
                copyTree(child, dir)
            } else {
                val mime = if (child.extension.equals("dat", true)) "application/octet-stream" else "application/octet-stream"
                val dest = target.createFile(mime, child.name ?: "file") ?: error("Cannot create file ${child.name}")
                contentResolver.openOutputStream(dest.uri)?.use { output -> child.inputStream().use { it.copyTo(output) } }
                    ?: error("Cannot write file ${child.name}")
            }
        }
    }
}
